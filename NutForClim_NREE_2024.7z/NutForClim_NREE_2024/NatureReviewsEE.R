interactions_table = read.table('literature_review.txt',header=T)
head(interactions_table)
attach(interactions_table)

library(tidyverse)

nutrient_summary_by_citation = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -climate,-experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(nutrient_reclass,organization_level,response,
           interpretation,citation) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(nutrient_reclass,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(nutrient_summary_by_citation, file = "nutrient_summary_by_citation.csv")

nutrient_summary_by_experiment = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -climate,-experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(nutrient_reclass,organization_level,response,
           interpretation,experiment) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(nutrient_reclass,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(nutrient_summary_by_experiment, file = "nutrient_summary_by_experiment.csv")

studytype_summary_by_citation = interactions_table %>%
  unite(study_type_manipulation, c(study_type, manipulation)) %>%
  filter(organization_level != "NA") %>%
  select(-id,-site,-study,-region,-ecosystem_type,
         -climate,-experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(study_type_manipulation,organization_level,response,
           interpretation,citation) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(study_type_manipulation,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(studytype_summary_by_citation, file = "studytype_summary_by_citation.csv")

studytype_summary_by_experiment = interactions_table %>%
  unite(study_type_manipulation, c(study_type, manipulation)) %>%
  filter(organization_level != "NA") %>%
  select(-id,-site,-study,-region,-ecosystem_type,
         -climate,-experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(study_type_manipulation,organization_level,response,
           interpretation,experiment) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(study_type_manipulation,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(studytype_summary_by_experiment, file = "studytype_summary_by_experiment.csv")

climate_summary_by_citation = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA",climate !="NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(climate,organization_level,response,
           interpretation,citation) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(climate,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(climate_summary_by_citation, file = "climate_summary_by_citation.csv")

climate_summary_by_experiment = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA",climate !="NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-taxonomy,-dominant_species,
         -age,-age_reclass) %>%
  group_by(climate,organization_level,response,
           interpretation,experiment) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(climate,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(climate_summary_by_experiment, file = "climate_summary_by_experiment.csv")

taxonomy_summary_by_citation = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA",taxonomy !="NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-dominant_species,
         -age,-age_reclass) %>%
  group_by(taxonomy,organization_level,response,
           interpretation,citation) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(taxonomy,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(taxonomy_summary_by_citation, file = "taxonomy_summary_by_citation.csv")

taxonomy_summary_by_experiment = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA",taxonomy !="NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-dominant_species,
         -age,-age_reclass) %>%
  group_by(taxonomy,organization_level,response,
           interpretation,experiment) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(taxonomy,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(taxonomy_summary_by_experiment, file = "taxonomy_summary_by_experiment.csv")

age_summary_by_citation = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-dominant_species,
         -age) %>%
  group_by(age_reclass,organization_level,response,
           interpretation,citation) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(age_reclass,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(age_summary_by_citation, file = "age_summary_by_citation.csv")

age_summary_by_experiment = interactions_table %>%
  filter(manipulation != "w",manipulation != "fw",organization_level != "NA") %>%
  select(-study_type,-manipulation,-id,-site,-study,-region,-ecosystem_type,
         -experiment_type,-community_type,-dominant_species,
         -age) %>%
  group_by(age_reclass,organization_level,response,
           interpretation,experiment) %>%
  summarize(counting = n()) %>%
  spread(interpretation,counting,fill = 0) %>%
  mutate("positive_temp" = ifelse(positive == 0,0,1),
         "0_temp" = ifelse(`0` == 0,0,1),
         "negative_temp" = ifelse(negative == 0,0,1)) %>%
  select(-`0`,-negative,-positive) %>%
  group_by(age_reclass,organization_level,response) %>%
  summarize("+" = sum(positive_temp),
            "0" = sum(`0_temp`),
            "-" = sum(negative_temp)) %>%
  mutate("net_effect" = ifelse(`+` > `-` & `+` >= `0` + `-`, "+",
                               ifelse(`-` > `+` & `-` >= `0` + `+`, "-",
                                      ifelse(`+` > `-`, "(+)",
                                             ifelse(`-` > `+`, "(-)","0")))))

write.table(age_summary_by_experiment, file = "age_summary_by_experiment.csv")

